/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.jme3.cinematic;

/**
 *
 * @author Nehon
 */
public interface PlayStateListener {

    public void onPlayStateChange(CinematicEvent cinematicEvent);

}
